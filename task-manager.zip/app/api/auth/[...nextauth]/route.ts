import { handlers } from '@/lib/auth/authOptions';

export const { GET, POST } = handlers;
